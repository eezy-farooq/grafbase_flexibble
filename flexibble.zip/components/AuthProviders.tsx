import React from 'react'

const AuthProviders = () => {
  return (
    <div>AuthProviders</div>
  )
}

export default AuthProviders